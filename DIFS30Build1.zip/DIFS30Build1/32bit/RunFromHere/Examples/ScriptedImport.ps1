﻿# DIFS
# Data Importer For SharePoint
# Scripted Import
# Ensure that you change the variables below prior to running the script

# Full path to your settings file
$pathtosettings = "\\vmware-host\Shared Folders\Projects\ProductDevelopment\ImportForSharePoint\WorkingArea\Examples\Office365_StaffFolders_Folders_Excel_Select.xml"
# Full path to where SPImportHelper.DLL is deployed
$pathtoassembly = "\\vmware-host\Shared Folders\Projects\ProductDevelopment\ImportForSharePoint\SourceCode\ImportForSharePoint\SPImportHelper\bin\Release";



# This loads the required assembliies
# You may need to change the path if DIFS is not installed in this location
[System.Reflection.Assembly]::LoadFile($pathtoassembly+"\SPImportHelper.dll") | Out-Null
[System.Reflection.Assembly]::LoadFile($pathtoassembly+"\Microsoft.SharePoint.Client.dll") | Out-Null
[System.Reflection.Assembly]::LoadFile($pathtoassembly+"\Microsoft.SharePoint.Client.Runtime.dll") | Out-Null
[System.Reflection.Assembly]::LoadFile($pathtoassembly+"\Microsoft.SharePoint.Client.Publishing.dll") | Out-Null
[System.Reflection.Assembly]::LoadFile($pathtoassembly+"\Microsoft.SharePoint.Client.Taxonomy.dll") | Out-Null

# We create a new import settings object using an existing settings file
$importsettings = [SPImportHelper.Settings.Utility]::LoadSettings($pathtosettings);

# We tell the user what source is being imported from
Write-Host "Source : Connection String : " $importsettings.Source.OleDbSourceDataSetSettings.ConnectionString

# We Create a new import object
$import = New-Object SPImportHelper.Import.DataSetImportToSharePoint_Console($importsettings);

# Write tell the user that we are starting the import
Write-Host "Importing";

# We start the import
$import.StartImport();

# Write tell the user that we have finished the import
Write-Host "Finished";


